public class FormaGeometrica {

}
