public class Casa {

}
