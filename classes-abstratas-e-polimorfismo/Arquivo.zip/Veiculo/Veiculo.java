package Veiculo;

public abstract class Veiculo {

}
