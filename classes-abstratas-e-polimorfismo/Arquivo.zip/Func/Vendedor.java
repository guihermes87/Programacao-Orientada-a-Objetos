package Func;

public class Vendedor {

}
