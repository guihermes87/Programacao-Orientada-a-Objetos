package Func;

public abstract class Funcionario {

}
