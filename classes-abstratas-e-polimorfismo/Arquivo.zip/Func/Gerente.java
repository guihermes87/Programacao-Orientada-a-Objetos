package Func;

public class Gerente {

        public void CalcularSalario() {
            System.out.println("Calculando o salário do gerente...");
        }

}
