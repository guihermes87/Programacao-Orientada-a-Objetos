package AcDados;

public interface AcessoDados {

}
