package AcDados;

public class BancoDeDados {

}
