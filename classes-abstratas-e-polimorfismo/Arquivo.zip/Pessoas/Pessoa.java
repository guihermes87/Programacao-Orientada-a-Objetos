package Veiculo;

public abstract class Pessoa {

}
